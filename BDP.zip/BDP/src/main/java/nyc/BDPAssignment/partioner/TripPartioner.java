package nyc.BDPAssignment.partioner;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/*
 * Partioner class for classifying different totals in to three different buckets
 * 
 */
public class TripPartioner extends
Partitioner < Text, FloatWritable >
{
   @Override
   public int getPartition(Text key, FloatWritable value, int numReduceTasks)
   {
      String[] str = key.toString().split(" ");
      String text = str[0]; 
      
      if(numReduceTasks == 0)
      {
         return 0;
      }
      
      //this conidtion checks for the overall total key parameters
      if(text.equalsIgnoreCase("Total") || text.equalsIgnoreCase("week") || text.equalsIgnoreCase("working"))
      {
         return 0;
      }
      else if(text.equalsIgnoreCase("WorkingDay")) // This condition checks for working day  in the key
      {
         return 1 % numReduceTasks;
      }
      else // This condition looks for week end in the key
      {
         return 2 % numReduceTasks;
      }
   }
}
